// src/theme.ts
export const appTheme = {
  VividPink: "#FF4081",
  VividOrange: "#FF5722",
  VividTeal: "#009688",
  Indigo: "#3F51B5",
  DarkIndigo: "#303F9F",
};
