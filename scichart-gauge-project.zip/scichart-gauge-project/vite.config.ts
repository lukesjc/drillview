import { defineConfig } from "vite";

export default defineConfig({
  assetsInclude: ['**/*.wasm', '**/*.js'],
  server: {
    port: 3000,
  }
});